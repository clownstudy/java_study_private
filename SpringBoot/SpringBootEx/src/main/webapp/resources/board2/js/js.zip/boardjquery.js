$("#up_btn").click(function(){
	window.name ="parentForm";
	window.open("updateForm.jsp","idCheck","width=500, height=200, resizable=no, scrollbar=no");
});